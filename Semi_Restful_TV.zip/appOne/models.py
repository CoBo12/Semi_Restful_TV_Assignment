from django.db import models


class show(models.Model):
    Title = models.CharField(max_length=255)
    Network = models.CharField(max_length=255)
    Release_date = models.DateField()
    Description = models.TextField(default="")
# Create your models here.
